<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CTFBD - MAZE IN ANTARJAL </title>
    <link rel="preconnect" href="https://p.typekit.net/" crossorigin>
    <link rel="preconnect" href="https://use.typekit.net/" crossorigin>
    <link rel="preload" href="./assets/css/ryt3opf.css" as="style">
    <link rel="preload" href="./assets/css/general_event.min3860.css?v=2" as="style">
    <link rel="preload" href="./assets/js/general_event.min.js" as="script">
    <link rel="icon" type="image/png" href="./images/hero/logo.png">
    <link rel="apple-touch-icon" href="./images/landingv3/favicon.png">

    <link rel="stylesheet" href="./assets/css/general_event.min3860.css?v=2">
    <script charset="utf-8" type="text/javascript" src="./assets/js/v2.js"></script>
    <script src="/assets/unpkg/%40lottiefiles/lottie-player%401.3.1/dist/lottie-player.js"></script>
    <script src="/assets/unpkg/%40lottiefiles/lottie-interactivity%401.3.1/dist/lottie-interactivity.min.js"></script>
    <meta name="author" content="" />
    <meta name="description" content="CTFBD - MAZE IN ANTARJAL" />
    <meta name="keywords" content="CTFBD" />
    <meta name="robots" content="index, follow" />
    <meta property="og:site_name" content="CTFBD - MAZE IN ANTARJAL" />
    <meta property="og:title" content="CTFBD - MAZE IN ANTARJAL | CTF-BD" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="./images/1.jpg" />
    <meta property="og:url" content="/" />
    <meta property="og:description" content="Antarjal - CTFBD" />
    <meta property="og:locale" content="en_US" />
    <style>
        header {
            position: relative;
            background-color: black;
            height: 100vh;
            min-height: 25rem;
            width: 100%;
            overflow: hidden;
        }

        header video {
            position: absolute;
            top: 50%;
            left: 50%;
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            z-index: 0;
            -ms-transform: translateX(-50%) translateY(-50%);
            -moz-transform: translateX(-50%) translateY(-50%);
            -webkit-transform: translateX(-50%) translateY(-50%);
            transform: translateX(-50%) translateY(-50%);
        }

        header .container {
            position: relative;
            z-index: 2;
        }

        header .overlay {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            z-index: 1;
        }

        .cus-btn-h {
            margin-top: 80vh;
            margin-bottom: 200px;
        }

        .chod {}

        @media (pointer: coarse) and (hover: none) {
            header {
                background: url('https://source.unsplash.com/XT5OInaElMw/1600x900') black no-repeat center center scroll;
            }

            .join-button {
                margin-top: 200px;
            }
        }

        @media screen and (max-width: 480px) {
            .show-on-desktop {
                display: none;
                !important;
            }

            .cus-btn-h {
                margin-top: 40vh;
            }

            header {
                height: 75vh;
            }

            .chod {
                margin-top: 222px;
            }
        }

        @media screen and (min-width: 481px) {
            .hide-on-desktop {
                display: none;
                !important;
            }

        }
    </style>
    <script>

    </script>
</head>

<body class="preload">
    <!--sticky header-->
    <div id="sticky-header" class="sticky-header sticky-header-responsive navbar-hidden nav-up "
        style="background: #111927">
        <section class="  d-block ">
            <div class="nav-menu-container container">
                <nav class="navbar nav-b2c tk-neue-haas-unica py-3" style="max-width: 1200px;margin:auto;">
                    <a class="navbar-brand" href= />
                    <img class=" " src="./images/logo.png" width="auto" height="100" alt="CTFBD - MAZE IN ANTARJAL "
                        title="CTFBD - MAZE IN ANTARJAL " />
                    </a>
                    <div class="d-flex align-items-center">
                        <ul class="navbar-nav navbar-menu-actions my-2 ml-5 my-lg-0 font-weight500 d-none d-lg-block">
                            <li class="nav-item">
                                <a target="_blank" class="btn btn-htb-green btn-htb-filled color-white"
                                    href="/register.html">REGISTER NOW</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </section>
    </div>
    <!--sticky header end-->
    <div class="bg-color-blue-bg position-relative">
        <!--animated hero starts-->
        <section class="hero-ctf uni-ctf-2021 bg-color-black " style="padding-bottom: 80px!important;">
            <header style="">
                <div class="overlay">
                    <div class="w-100 h-100 parent show-on-desktop p-0"
                        style="position:relative; z-index: 2; margin-top: -20px;">
                        <div class="d-flex flex-column position-relative mt-2"
                            style="padding-left: 50px; padding-right: 50px">
                            <img src="./images/overlay.png" class="img-fluid" />
                        </div>

                    </div>
                    <div class="container w-100 parent hide-on-desktop">
                        <div class="d-flex flex-column position-relative mt-2">
                            <img src="./images/overlay.png" class="img-fluid" />
                        </div>

                    </div>
                </div>
                <video id="hero" class="video" playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop">
                    <source src="./assets/video/o_video.mp4" type="video/mp4">
                </video>
                <div class="container join-button mb-8 text-center">
                    <a id="register-cta1" href="/register.html" target="_blank"
                        class="btn btn-htb-green btn-htb-filled letter-spacing-1-2 color-white cus-btn-h chod">REGISTER
                        NOW</a>
                </div>

            </header>

        </section>
    </div>
    <!--        light imgs end-->
    <!--        gear imgs start-->

    <!--        gear imgs end-->


    <!--    animated hero section ends-->
    <section class="content">
        <div class="container mt-4">
            <div class="row justify-content-center mt-5">
                <div class="col-12 col-lg-7 color-white main-content ">
                    <section class="fixed-tabs-horizontal ">
                        <div class="row sticky-top bg-color-blue-bg d-none">
                            <div class="col-12 fixed-tabs-container">
                                <ul id="fixed-tabs" class="d-none d-md-flex nav nav-pills nav-justified">
                                    <li class="nav-item">
                                        <a class="nav-link color-main font-size10 font-weight500 letter-spacing-1-2 rounded-0 pb-3 active"
                                            href="#overview">OVERVIEW</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link color-main font-size10 font-weight500 letter-spacing-1-2 rounded-0 pb-3 "
                                            href="#timeline">TIMELINE</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link color-main font-size10 font-weight500 letter-spacing-1-2 rounded-0 pb-3 "
                                            href="#prize_pool">PRIZE POOL</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link color-main font-size10 font-weight500 letter-spacing-1-2 rounded-0 pb-3 "
                                            href="#rules">RULES</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </section>
                    <!--                    countdown section-->
                    <section id="overview" class="countdown text-center">
                        <div class="row mb-2 " id="timer">

                        </div>
                    </section>
                    <!--                    countdown section end-->
                    <!--                    overview section-->
                    <section class="overview">
                        <div class="row pb-14">
                            <div class="col-12 col-md-4 mb-3">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="icon-wrapper pb-3">
                                        <img src="https://www.hackthebox.com/images/landingv3/general_event/flag-icon.svg"
                                            alt="" />
                                    </div>
                                    <div class="title-wrapper ">
                                        <span class="font-size18 font-weight600">Event Type</span>
                                    </div>
                                    <div class="subtitle-wrapper">
                                        <p class="font-size15 font-weight400">Capture The Flag</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 mb-3">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="icon-wrapper pb-3">
                                        <img src="https://www.hackthebox.com/images/landingv3/general_event/pin-icon.svg"
                                            alt="" />
                                    </div>
                                    <div class="title-wrapper ">
                                        <span class="font-size18 font-weight600">Place</span>
                                    </div>
                                    <div class="subtitle-wrapper">
                                        <p class="font-size15 font-weight400">Online</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="icon-wrapper pb-3">
                                        <img src="https://www.hackthebox.com/images/landingv3/general_event/ic-tag.svg"
                                            alt="" />
                                    </div>
                                    <div class="title-wrapper ">
                                        <span class="font-size18 font-weight600">Entry Fee</span>
                                    </div>
                                    <div class="subtitle-wrapper">
                                        <p class="font-size15 font-weight400">Free</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="icon-wrapper pb-3">
                                        <img src="https://www.hackthebox.com/images/landingv3/general_event/group-icon.svg"
                                            alt="" />
                                    </div>
                                    <div class="title-wrapper ">
                                        <span class="font-size18 font-weight600">Team Size</span>
                                    </div>
                                    <div class="subtitle-wrapper">
                                        <p class="font-size15 font-weight400">2-3 Members</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="icon-wrapper pb-3">
                                        <img src="https://www.hackthebox.com/images/landingv3/general_event/ic-difficulty.svg"
                                            alt="" />
                                    </div>
                                    <div class="title-wrapper ">
                                        <span class="font-size18 font-weight600">Difficulty</span>
                                    </div>
                                    <div class="subtitle-wrapper">
                                        <p class="font-size15 font-weight400">Easy to Hard</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-12 mb-3">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="icon-wrapper pb-3">
                                        <img src="https://www.hackthebox.com/images/landingv3/general_event/ic-ctfstyle.svg"
                                            alt="" />
                                    </div>
                                    <div class="title-wrapper ">
                                        <span class="font-size18 font-weight600">CTF Style</span>
                                    </div>
                                    <div class="subtitle-wrapper">
                                        <p class="font-size15 font-weight400">Jeopardy</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!--                    overview ends-->
                    <!--                    about starts-->
                    <section class="about-event pb-14">
                        <div class="row pb-4">
                            <div class="col-12 ">
                                <h5 class="font-weight600 font-size32 color-green letter-spacing-2 pb-2 text-uppercase">
                                    about the event</h5>
                                <h3 class="font-weight400 font-size28 color-white pb-3"
                                    style="color: #2ba1ff!important;">Nation Wide</h3>
                            </div>
                        </div>
                        <div class="row ">
                            <div class="col-12 ">
                                <div class="description m-0">
                                    <p>CTFBD - MAZE IN ANTARJAL is a CyberSecurity competition organized by <span
                                            class="color-green">CTF Community Bangladesh</span> The contest is intended
                                        to mobilize the energies of everyone, their knowledge and abilities on hacking
                                        information systems and applications in a controlled and challenging
                                        environment.</p>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!--                    about ends-->
                    <section class="donate pb-14">
                        <div class="row pb-4">
                            <div class="col-12 ">
                                <h5 class="font-weight600 font-size32 color-green letter-spacing-2 pb-2 text-uppercase">
                                    LET’S MAKE AN IMPACT</h5>
                                <h3 class="font-weight400 font-size28 color-white pb-3"
                                    style="color: #2ba1ff!important;">Hack for Good</h3>
                            </div>
                        </div>
                        <div class="row ">
                            <div class="col-12">
                                <div class="ctf-image__wrap "> <img class="mw-100 w-100 border-radius-10"
                                        src="./images/3.jpg" alt="Hack The Box Prizes"> </div>
                            </div>
                        </div><br><br>
                        <div class="row pt-4">
                            <div class="col-12 ">
                                <p class="description m-0">The main objective of this computational event is to
                                    encourage students to develop their skills, to train and exercise both intellectual
                                    and practical abilities in the Cyber Security field as future specialists.<br><br>
                                    The contest, organized as a CTF competition (Capture The Flag), is based on solving
                                    challenges from a diverse range of categories such as web exploitation, forensics,
                                    reverse engineering, binary exploitation and more! We made sure that each category
                                    has challenges for every skill level, so that there is always something for everyone
                                    to enjoy and work on. This competition is using a dynamic scoring system, meaning
                                    that the more solves a challenge, the less points it will bring to each of the
                                    solving teams. This system is put in place in order to keep the challenge score
                                    updated to its real difficulty level.
                                </p>
                            </div>
                        </div>
                    </section>
                    <!--                    join section-->
                    <section class="why-join pb-14">
                        <div class="row pb-4">
                            <div class="col-12 ">
                                <h5 class="font-weight600 font-size32 color-green letter-spacing-2 pb-2 text-uppercase">
                                    WHY JOIN</h5>
                                <h3 class="color-white font-size28 font-weight400" style="color: #2ba1ff!important;">
                                    Glory, learning, prizes</h3>
                            </div>
                        </div>
                        <div class="row ">
                            <div class="col-12 pb-4">
                                <div class="description m-0">
                                    <span class="color-white font-size18 font-weight500">Hack amazing content</span>
                                    <p>Learn with the best hacking content from the Bangladeshi CTF community!</p>
                                    <br>
                                    <span class="color-white font-size18 font-weight500">Win the best prizes</span>
                                    <p>A never-seen-before prize list is awaiting the top teams!</p>
                                    <br>
                                    <span class="color-white font-size18 font-weight500">Climb the scoreboard</span>
                                    <p>Achieve eternal glory and show your team is the best!</p>
                                    <br>
                                    <span class="color-white font-size18 font-weight500">Get CTF-Certified</span>
                                    <p>For all players with 200+ points.</p>
                                    <br>
                                </div>
                            </div>
                        </div>
                        <div class="row ">
                            <!--  <div class="col-12">
                                <div class="ctf-image__wrap ">
                                    <img class="mw-100 w-100 border-radius-10" src="./images/1.jpg" alt="Hack The Box Prizes">
                                </div>
                            </div> -->

                        </div>
                    </section>
                    <!--                    join section end-->
                    <!--                    hacking content --><br><br>
                    <section class="hacking-content pb-14">
                        <div class="row pb-4">
                            <div class="col-12 ">
                                <h5 class="font-weight600 font-size32 color-green letter-spacing-2 pb-2 text-uppercase">
                                    competition category</h5>
                                <h3 class="font-weight400 font-size28 color-white pb-3"
                                    style="color: #2ba1ff!important;">Challenges for You</h3>
                            </div>
                        </div>
                        <div class="row pb-4">
                            <div class="col-md-4 mb-3 text-center">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="title-wrapper "> <span class="font-size18 font-weight600">Web
                                            Exploitation</span> </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3 text-center">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="title-wrapper "> <span class="font-size18 font-weight600">Digital
                                            Forensic</span> </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3 text-center">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="title-wrapper "> <span
                                            class="font-size18 font-weight600">Cryptography</span> </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3 text-center">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="title-wrapper "> <span
                                            class="font-size18 font-weight600">Steganography</span> </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3 text-center">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100">
                                    <div class="title-wrapper "> <span class="font-size18 font-weight600">Reverse
                                            Engineering</span> </div>
                                </div>
                            </div>
                        </div>
                    </section><br>
                    <!--                    hacking content ends-->
                    <!--                    timeline section-->
                    <section class="agenda ctf-timeline " id="timeline">
                        <div class="row pb-4">
                            <div class="col-12 ">
                                <h5 class="font-weight400 font-size13 color-green letter-spacing-2 pb-2 text-uppercase">
                                    TIMELINE</h5>
                                <h3 class="color-white font-size32 font-weight600" style="color: #2ba1ff!important;">
                                    CTFBD - MAZE IN ANTARJAL: Mark the dates</h3>
                            </div>
                        </div>
                        <div class="row pt-4 pb-14">
                            <div class="col-12 ">
                                <div class="timeline">
                                    <div class="timeline-row d-flex">
                                        <div class="timeline-checkpoints">
                                            <img src="https://www.hackthebox.com/images/landingv3/general_event/bullet-timeline.svg"
                                                alt="">
                                            <div class="dotted-line"></div>
                                        </div>
                                        <div class="card w-100">
                                            <h5 class="font-size18 mb-0">Registration Opens</h5>
                                            <p class="font-size-18 m-0">June 6, 2023</p>
                                        </div>
                                    </div>
                                    <div class="timeline-row d-flex">
                                        <div class="timeline-checkpoints">
                                            <img src="https://www.hackthebox.com/images/landingv3/general_event/bullet-timeline.svg"
                                                alt="">
                                            <div class="dotted-line"></div>
                                        </div>
                                        <div class="card w-100">
                                            <h5 class="font-size18 mb-0">Registration Closes</h5>
                                            <p class="font-size-18 m-0">July 02, 2023</p>
                                        </div>
                                    </div>
                                    <div class="timeline-row d-flex">
                                        <div class="timeline-checkpoints">
                                            <img src="https://www.hackthebox.com/images/landingv3/general_event/bullet-timeline.svg"
                                                alt="">
                                            <div class="dotted-line"></div>
                                        </div>
                                        <div class="card w-100">
                                            <h5 class="font-size18 mb-0">Date of Competition</h5>
                                            <p class="font-size-18 m-0">July 07, 2023</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- /flag -->
                    <!--                    timeline ends-->
                    <!--                    sponsors end-->
                    <!--                    prize pool-->
                    <section id="prize_pool" class="ctf-prize tab-section pb-14">
                        <div class="row pb-4">
                            <div class="col-12 ">
                                <h5 class="font-weight600 font-size32 color-green letter-spacing-2 pb-2 text-uppercase">
                                    prize pool</h5>
                                <h3 class="font-weight400 font-size28 color-white pb-3"
                                    style="color: #2ba1ff!important;">It’s All About Prizes</h3>
                            </div>
                        </div>
                        <div class="ctf-daily-schedule">
                            <div class="row pt-4 ">
                                <div class="col-12 mb-4">
                                    <div class="medal ctf-prize__img">
                                        <img class="w-100" src="./images/2.jpg" alt="Hack The Box Prizes">
                                    </div>
                                </div>
                                <div class="col-12 ">

                                    <div class="tab-content">
                                        <div class="tab-pane fade show active" id="pills-quals_ctf" role="tabpanel"
                                            aria-labelledby="pills-quals_ctf-tab">
                                            <div class="row pt-4">
                                                <div class="col-12 ">

                                                    <p> Prizes Uncover, solve, and triumph to win not just the title of
                                                        "Cyber Security Hero but also exclusive merchandise from the
                                                        movie, premiere tickets, and a chance to meet the cast! </p>

                                                    <ol class="rules-list color-main">
                                                        <li class="pb-4" style="font-size: 18px"> Prizes Uncover, solve,
                                                            and triumph to win not just the title of "Cyber Security
                                                            Hero" but also Top 3 Teams will get exclusive gift,
                                                            merchandise from the movie, premiere tickets from ANTARJAL
                                                            TEAM.</li>
                                                        <li class="pb-4" style="font-size: 18px">Top 10 teams will get
                                                            swag pack.</li>
                                                        <li class="pb-4" style="font-size: 18px"> Lucky 10 teams will
                                                            get exculisive giveaway!</li>

                                                    </ol>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><br><br>

                    </section>
                    <!--                    prize pool ends-->
                    <!--                    rules-->
                    <section id="rules" class="pb-14">
                        <div class="row py-4">
                            <div class="col-12 ">
                                <h5 class="font-weight600 font-size32 color-green letter-spacing-2 pb-2 text-uppercase">
                                    FOR A FAIR PLAY</h5>
                                <h3 class="font-weight400 font-size28 color-white pb-3"
                                    style="color: #2ba1ff!important;">Rules Of The Game</h3>
                            </div>
                        </div>
                        <div class="row ">
                            <div class="col-12 ">
                                <ol class="rules-list color-main">
                                    <li class="pb-4" style="font-size: 18px">Do not attack the backend infrastructure of
                                        the CTF.</li>
                                    <li class="pb-4" style="font-size: 18px">Do not attack other teams playing in the
                                        CTF.</li>
                                    <li class="pb-4" style="font-size: 18px">Do not brute-force the flag submission
                                        form.</li>
                                    <li class="pb-4" style="font-size: 18px">Flag format is CTFBD{a-zA-Z0-9}
                                    </li>
                                    <li class="pb-4" style="font-size: 18px">Do not exchange flags or write-ups/hints of
                                        the challenges with other teams.</li>
                                    <li class="pb-4" style="font-size: 18px">Do not try to DDoS the challenges or make
                                        actions that could lead to this result. For example, brute force or use of
                                        automated tools with many threads.</li>
                                    <li class="pb-4" style="font-size: 18px">Do not be part of more than one team within
                                        the same CTF.</li>
                                </ol>
                            </div>
                        </div>
                    </section>
                    <!--                    rules end-->
                    <!--                    last year-->
                    <section id="rules1" class="pb-14">
                        <div class="row py-4">
                            <div class="col-12 ">
                                <h5 class="font-weight600 font-size32 color-green letter-spacing-2 pb-2 text-uppercase">
                                    MUST WATCH THINGS</h5>
                                <h3 class="font-weight400 font-size28 color-white pb-3"
                                    style="color: #2ba1ff!important;">Things You Should Notice</h3>
                            </div>
                        </div>
                        <div class="row ">
                            <div class="col-12 ">
                                <ol class="rules-list color-main" style="font-size: 18px">
                                    <li class="pb-4" style="font-size: 18px">For every participant there will be a
                                        special recognition and certificate.</li>
                                    <li class="pb-4" style="font-size: 18px">After successful registration, we will
                                        notify you through a confirmation mail.</li>
                                    <li class="pb-4" style="font-size: 18px">If anyone needs any assistance please
                                        contact us through our <a
                                            href="https://www.facebook.com/ctfcommunitybd">Facebook Page</a>.</li>
                                </ol>
                            </div>
                        </div>
                        <div class="row mt-5">
                            <div class="col-md-3 mb-3 text-center">
                                <div
                                    class="overview-card bg-color-blue-nav border-radius-10 p-4 h-100 d-flex flex-column justify-content-center align-items-center">
                                    <div class="title-wrapper "> <span
                                            class="font-size18 font-weight600 color-main">Follow Us</span> </div>
                                    <div class="subtitle-wrapper">
                                        <p class="font-size15 font-weight400">On<br><a class="color-green"
                                                href="https://www.facebook.com/ctfcommunitybd"
                                                target="_blank">Facebook</a></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3 text-center">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100 d-flex flex-column justify-content-center align-items-center">
                                    <div class="title-wrapper "> <span
                                            class="font-size18 font-weight600 color-main">Follow Us</span> </div>
                                    <div class="subtitle-wrapper">
                                        <p class="font-size15 font-weight400">On<br><a class="color-green"
                                                href="https://twitter.com/ctfcommunitybd" target="_blank">Twitter</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3 text-center">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100 d-flex flex-column justify-content-center align-items-center">
                                    <div class="title-wrapper "> <span
                                            class="font-size18 font-weight600 color-main">Join Us</span> </div>
                                    <div class="subtitle-wrapper">
                                        <p class="font-size15 font-weight400">On<br><a class="color-green"
                                                href="https://discord.gg/qgaGdRVB" target="_blank">Discord</a></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3 text-center">
                                <div
                                    class="overview-card align-content-stretch bg-color-blue-nav border-radius-10 p-4 h-100 d-flex flex-column justify-content-center align-items-center">
                                    <div class="title-wrapper "> <span
                                            class="font-size18 font-weight600 color-main">Join Our</span> </div>
                                    <div class="subtitle-wrapper">
                                        <p class="font-size15 font-weight400">Official<br><a class="color-green"
                                                href="https://www.facebook.com/groups/ctf.community.bd"
                                                target="_blank">FB Group</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!--                    last year ends-->

                </div>
                <div class="d-none d-lg-block col-lg-4 ml-md-5 right-sidebar">
                    <div class="position-sticky d-none d-lg-block pb-6 sticky-content">
                        <div class="reservation-card bg-color-blue-nav color-white">
                            <p class="text-center color-green font-size32 font-weight600">CTFBD - MAZE IN ANTARJAL</p>
                            <p class="date" style="color: #2ba1ff!important;">Reg Deadline -
                                July 02, 2023</p>
                            <p class="color-white">Please read the instructions carefully and fill out the form.</p>
                            <div class="reservation-card__tags pb-4">
                                <div class="d-none">
                                    <img src="https://www.hackthebox.com/images/landingv3/b2b_webinars/svg/clock.svg"
                                        height="16px" alt="">
                                    <p></p>
                                </div>
                                <div class="d-none">
                                    <img src="https://www.hackthebox.com/images/landingv3/b2b_webinars/svg/pin.svg"
                                        height="16px" alt="">
                                    <p>Online Live</p>
                                </div>
                                <div class="d-none">
                                    <img src="https://www.hackthebox.com/images/landingv3/b2b_webinars/svg/tag.svg"
                                        height="16px" alt="">
                                    <p>Free</p>
                                </div>
                                <div class="d-block">
                                    <p class="text-uppercase color-green letter-spacing-1-2 font-size10">Start Time</p>
                                    <p class="font-size15 color-white"> July 07, 2023 </p>
                                </div>
                                <div class="d-block">
                                    <p class="text-uppercase color-green letter-spacing-1-2 font-size10">End Time</p>
                                    <p class="font-size15 color-white">July 07,2023</p>
                                </div>
                            </div>
                            <div> <a id="reserve" href="/register.html" target="_blank"
                                    class="btn btn-htb-green btn-htb-filled letter-spacing-1-2 w-100">REGISTER NOW</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>
    <section class="footer">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-5 text-center">
                    <a class="d-inline-block" href="/">
                        <img alt="CTFBD - MAZE IN ANTARJAL" src="images/logo.png" style="width: auto; height: 100px">
                    </a>
                    <a class="link main-link " href="javascript:void(0)"
                        style="font-size: 13px; letter-spacing: 1.2px; font-weight: 600;">Follow Us</a>
                    <div class="social-icons mt-2">
                        <a href="https://www.facebook.com/ctfcommunitybd" target="_blank"> <img
                                src="./images/icons/SML-01.png" style="width: 50px; height: 50px" alt="" /> </a>
                        <a href="https://twitter.com/ctfcommunitybd" target="_blank"> <img
                                src="./images/icons/SML-02.png" style="width: 50px; height: 50px" alt="" /> </a>
                        <a href="https://discord.gg/qgaGdRVB" target="_blank"> <img src="./images/icons/SML-03.png"
                                style="width: 50px; height: 50px" alt="" /> </a>
                    </div>
                </div>

            </div>
            <div class="row justify-content-center mt-1 mt-sm-2 text-center copyrights-wrapper">
                <div class="col-auto copyright mx-4">© 2023 CTF Community Bangladesh</div>
            </div>
        </div>
    </section>
    <script data-cookieconsent="ignore" src="./assets/js/general_event.min.js"></script>
    <script> (function (ss, ex) { window.ldfdr = window.ldfdr || function () { (ldfdr._q = ldfdr._q || []).push([].slice.call(arguments)); }; (function (d, s) { fs = d.getElementsByTagName(s)[0]; function ce(src) { var cs = d.createElement(s); cs.src = src; cs.async = 1; fs.parentNode.insertBefore(cs, fs); }; ce('https://sc.lfeeder.com/lftracker_v1_' + ss + (ex ? '_' + ex : '') + '.js'); })(document, 'script'); })('3P1w24dxvvJ4mY5n'); </script>
    <script> (function (h, o, t, j, a, r) { h.hj = h.hj || function () { (h.hj.q = h.hj.q || []).push(arguments) }; h._hjSettings = { hjid: 2599056, hjsv: 6 }; a = o.getElementsByTagName('head')[0]; r = o.createElement('script'); r.async = 1; r.src = t + h._hjSettings.hjid + j + h._hjSettings.hjsv; a.appendChild(r); })(window, document, 'https://static.hotjar.com/c/hotjar-', '.js?sv='); </script>
    <script type="text/javascript" id="hs-script-loader" async defer src="../../js.hs-scripts.com/5514032.js"></script>
    <script
        type="text/javascript"> (function () { window.sib = { equeue: [], client_key: "fq9zuyy2crzzc0fpp4frw6kp" }; window.sendinblue = {}; for (var j = ['track', 'identify', 'trackLink', 'page'], i = 0; i < j.length; i++) { (function (k) { window.sendinblue[k] = function () { var arg = Array.prototype.slice.call(arguments); (window.sib[k] || function () { var t = {}; t[k] = arg; window.sib.equeue.push(t); })(arg[0], arg[1], arg[2]); }; })(j[i]); } var n = document.createElement("script"), i = document.getElementsByTagName("script")[0]; n.type = "text/javascript", n.id = "sendinblue-js", n.async = !0, n.src = "../../sibautomation.com/sa08e2.js?key=" + window.sib.client_key, i.parentNode.insertBefore(n, i), window.sendinblue.page(); })(); </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossOrigin="anonymous"></script>
    <script>
        $(document).ready(function () {
            $('.to-hide').css({
                'opacity': '1',
            });
        });
        var $window = $(window);
        var breakpoint = 991;
        var last = $window.width() > breakpoint;
        //play video on hover
        if (last) {
            $(document).ready(function () {
                if ($(window).width() < 600) {
                    console.log('mobile')
                    $('#desk').hide();
                    $('#mobile').show();
                }
                else {
                    console.log('mobile')
                    $('#desk').show();
                    $('#mobile').hide();
                }
            })
            $(document).on('mouseover', '.parent', function () { //selecting the document 1st will grab new content
                $(this).find('header > video').first().trigger('play');

            });
        }
        function updateTimer() {
            let future = Date.parse("July 03, 2023 00:00:00");
            let now = new Date();
            let diff = future - now;
            let days, hours, mins, secs;
            if (diff > 0) {
                days = Math.floor(diff / (1000 * 60 * 60 * 24));
                hours = Math.floor(diff / (1000 * 60 * 60));
                mins = Math.floor(diff / (1000 * 60));
                secs = Math.floor(diff / 1000);
            } else {
                days = 0;
                hours = 0;
                mins = 0;
                secs = 0;
            }


            let d = days;
            let h = hours - days * 24;
            let m = mins - hours * 60;
            let s = secs - mins * 60;

            document.getElementById("timer")
                .innerHTML =
                '<div class="col-6 col-sm-3">' +
                '                                <div class="d-inline-block bg-color-blue-nav border-radius-10 py-4 mb-3 w-100">' +
                '                                    <div id="days" class="font-size42 font-weight700 mb-2 color-white">' + d + '</div>' +
                '                                    <div class="color-green">Days</div>' +
                '                                </div>' +
                '                            </div>' +
                '<div class="col-6 col-sm-3">' +
                '                                <div class="d-inline-block bg-color-blue-nav border-radius-10 py-4 mb-3 w-100">' +
                '                                    <div id="days" class="font-size42 font-weight700 mb-2 color-white">' + h + '</div>' +
                '                                    <div class="color-green">Hours</div>' +
                '                                </div>' +
                '                            </div>' +
                '<div class="col-6 col-sm-3">' +
                '<div class="d-inline-block bg-color-blue-nav border-radius-10 py-4 mb-3 w-100">' +
                '                                    <div id="days" class="font-size42 font-weight700 mb-2 color-white">' + m + '</div>' +
                '                                    <div class="color-green">Minutes</div>' +
                '                                </div>' +
                '                            </div>' +
                '<div class="col-6 col-sm-3">' +
                '<div class="d-inline-block bg-color-blue-nav border-radius-10 py-4 mb-3 w-100">' +
                '                                    <div id="days" class="font-size42 font-weight700 mb-2 color-white">' + s + '</div>' +
                '                                    <div class="color-green">Seconds</div>' +
                '                                </div>' +
                '                            </div>';
        }
        setInterval('updateTimer()', 1000);

    </script>
</body>

</html>