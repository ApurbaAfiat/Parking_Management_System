<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="../../../css/style.css">
    <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <script defer src="../../../js/bootstrap.bundle.js"></script>
    <style>
        /* Stylish background */
        body {
            background-color: #f4f4f4;
            font-family: 'Arial', sans-serif;
            position: relative;
            min-height: 100vh;
        }

        /* Navbar styles */
        .navbar {
            background: linear-gradient(45deg, #333366, #4A4A80);
        }

        .navbar-brand, .nav-link {
            color: white !important;
            transition: color 0.3s ease-in-out;
            font-weight: bold;
        }

        .navbar-brand:hover, .nav-link:hover {
            color: #FFCC00 !important;
        }

        /* Main container */
        .fix-slot-container {
            max-width: 800px;
            margin: 50px auto;
            text-align: center;
        }

        /* Input styles */
        .fix-slot-input {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            border-radius: 10px;
            border: 1px solid #ccc;
            text-align: center;
            font-size: 18px;
        }

        /* Slot matrix styles */
        .slot-matrix {
            display: none; /* Initially hidden */
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
            margin-top: 20px;
        }

        .slot {
            width: 100%;
            height: 60px;
            border-radius: 10px;
            font-size: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .slot.green {
            background-color: #28a745;
            color: white;
        }

        .slot.red {
            background-color: #dc3545;
            color: white;
            pointer-events: none; /* Disable clicking */
        }

        .slot:hover {
            opacity: 0.9;
        }

        /* Submit button */
        .submit-button {
            display: block;
            margin-top: 20px;
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            background-color: #333366;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .submit-button:hover {
            background-color: #4A4A80;
        }

        /* Footer styles */
        footer {
            background-color: #333366;
            color: white;
            text-align: center;
            padding: 10px 0;
            width: 100%;
            transition: background-color 0.3s ease-in-out;
            clear: both;
        }

        footer:hover {
            background-color: #666699;
        }

    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../Homepage/Homepage.php">Parking Management System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                <ul class="navbar-nav ms-auto mb-2 mx-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active btn btn-primary" aria-current="page" href="../Login/Login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link profile-btn" href="../Profile/index.php">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <div class="fix-slot-container">
            <!-- Date input -->
            <input type="date" id="date-input" class="fix-slot-input" placeholder="Select Date">

            <!-- Level selection -->
            <div class="fix-slot-input">
                <select id="level-select" style="width: 100%; border: none; outline: none; font-size: 18px;">
                    <option value="" disabled selected>Select Level</option>
                    <option value="level1">Level 1</option>
                    <option value="level2">Level 2</option>
                    <option value="level3">Level 3</option>
                    <!-- Add more levels as needed -->
                </select>
            </div>

            <!-- Slot matrix -->
            <div class="slot-matrix" id="slotMatrix"></div>

            <!-- Submit button -->
            <button class="submit-button" onclick="submitSlot()">Book Your Slot</button>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Parking Management System</p>
    </footer>

    <script>
        let slots = [
            { id: 'A1', status: 'green' }, { id: 'A2', status: 'red' }, { id: 'A3', status: 'green' }, { id: 'A4', status: 'green' }, { id: 'A5', status: 'red' },
            { id: 'B1', status: 'green' }, { id: 'B2', status: 'green' }, { id: 'B3', status: 'red' }, { id: 'B4', status: 'green' }, { id: 'B5', status: 'red' },
            { id: 'C1', status: 'green' }, { id: 'C2', status: 'red' }, { id: 'C3', status: 'green' }, { id: 'C4', status: 'red' }, { id: 'C5', status: 'green' },
            { id: 'D1', status: 'red' }, { id: 'D2', status: 'green' }, { id: 'D3', status: 'green' }, { id: 'D4', status: 'red' }, { id: 'D5', status: 'green' }
        ];

        function generateSlots() {
            const matrix = document.getElementById('slotMatrix');
            matrix.innerHTML = ''; // Clear previous slots

            slots.forEach(slot => {
                const div = document.createElement('div');
                div.classList.add('slot', slot.status);
                div.textContent = slot.id;
                div.onclick = function() {
                    if (slot.status === 'green') {
                        slot.status = 'red'; // Update slot status to red
                        div.classList.remove('green');
                        div.classList.add('red');
                        alert('Slot selected: ' + slot.id);
                    }
                };
                matrix.appendChild(div);
            });
            matrix.style.display = 'grid'; // Display the slot matrix
        }

        function submitSlot() {
            // Handle slot submission logic here
            alert('Slot submitted successfully!');
        }

        document.getElementById('level-select').addEventListener('change', function() {
            // Fetch and display slots for the selected level
            generateSlots();
        });
    </script>

</body>

</html>