<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="../../../css/style.css">
    <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <script defer src="../../../js/bootstrap.bundle.js"></script>
    <style>
        /* Stylish background */
        body {
            background-color: #f4f4f4;
            font-family: 'Arial', sans-serif;
            position: relative;
            min-height: 100vh;
        }

        /* Navbar styles */
        .navbar {
            background: linear-gradient(45deg, #333366, #4A4A80);
        }

        .navbar-brand, .nav-link {
            color: white !important;
            transition: color 0.3s ease-in-out;
            font-weight: bold;
        }

        .navbar-brand:hover, .nav-link:hover {
            color: #FFCC00 !important;
        }

        /* Payment options */
        .payment-container {
            max-width: 600px;
            margin: 50px auto;
            text-align: center;
            
        }

        .payment-options {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .payment-option {
            flex: 1;
            height: 200px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out, transform 0.3s ease-in-out;
            position: relative;
            overflow: hidden;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .payment-option:hover {
            opacity: 0.9;
            transform: scale(1.05);
        }

        .one-month {
            background-color: #FF5733;
        }

        .one-year {
            background-color: #3357FF;
        }

        .input-container {
            margin-top: 20px;
        }

        .amount-input {
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            border: 1px solid #ccc;
            text-align: center;
            font-size: 18px;
        }

        .payment-methods {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .payment-method {
            flex: 1;
            height: 100px;
            margin: 0 10px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .payment-method:hover {
            opacity: 0.9;
        }

        .bkash {
            background-color: #333366;
        }

        .rocket {
            background-color: #4A4A80;
        }

        .nagad {
            background-color: #3357FF;
        }

        .pay-now-button {
            display: block;
            margin-top: 20px;
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            background-color: #333366;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .pay-now-button:hover {
            background-color: #4A4A80;
        }

        /* Footer styles */
        footer {
            background-color: #333366;
            color: white;
            text-align: center;
            padding: 10px 0;
            width: 100%;
            transition: background-color 0.3s ease-in-out;
            clear: both;
        }

        footer:hover {
            background-color: #666699;
        }

    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../Homepage/Homepage.php">Parking Management System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                <ul class="navbar-nav ms-auto mb-2 mx-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active btn btn-primary" aria-current="page" href="../Login/Login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link profile-btn" href="../Profile/index.php">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="payment-container">
            <h2 class="text-center mb-4">Choose a Plan</h2>
            <div class="payment-options">
                <div class="payment-option one-month" onclick="selectPlan('1190')">1 Month Plan</div>
                <div class="payment-option one-year" onclick="selectPlan('9990')">1 Year Plan</div>
            </div>
            <div class="input-container">
                <input type="text" id="amount-input" class="amount-input" readonly>
            </div>
            <p class="text-center mt-3" style="font-size: 20px; font-weight: bold;">Select your payment method:</p>
            <div class="payment-methods">
                <div class="payment-method bkash" onclick="selectMethod('bKash')">bKash</div>
                <div class="payment-method rocket" onclick="selectMethod('Rocket')">Rocket</div>
                <div class="payment-method nagad" onclick="selectMethod('Nagad')">Nagad</div>
            </div>
            <div class="text-center mt-3">
                <button class="pay-now-button" onclick="payNow()">Pay Now</button>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Parking Management System</p>
    </footer>

    <script>
        function selectPlan(amount) {
            document.getElementById('amount-input').value = amount + ' taka';
        }

        function selectMethod(method) {
            alert('Payment method selected: ' + method);
        }

        function payNow() {
            alert('Payment processed successfully!');
        }
    </script>

</body>

</html>