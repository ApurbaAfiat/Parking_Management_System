
<<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Login</title>
  <link href="login.css" rel="stylesheet"/>
</head>
<body>
  <div class="login-page">
    <div class="form">
      <form class="login-form"  action="../AdminPanel/adminlandingpage.php">
      <h2 class="mb-4">Admin Login</h2>
        <input type="text" placeholder="username"/>
        <input type="password" placeholder="password"/>
        <button>login</button>
        <p class="message"> Want to Login as Normal User? <a href="../Login/login.php">Click Here</a></p>
      </form>
    </div>
  </div>
</body>
</html>
