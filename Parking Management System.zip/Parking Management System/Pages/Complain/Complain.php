<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="../../../css/style.css">
    <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <script defer src="../../../js/bootstrap.bundle.js"></script>
    <style>
        /* Stylish background */
        body {
            background-color: #f4f4f4;
            font-family: 'Arial', sans-serif;
        }

        /* Navbar styles */
        .navbar {
            background: linear-gradient(45deg, #333366, #4A4A80);
        }

        .navbar-brand, .nav-link {
            color: white !important;
            transition: color 0.3s ease-in-out;
            font-weight: bold;
        }

        .navbar-brand:hover, .nav-link:hover {
            color: #FFCC00 !important;
        }

        /* Complain form styles */
        .complain-form {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .complain-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 10px;
            border: 1px solid #ccc;
            resize: none;
            height: 150px;
        }

        .complain-form button {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            background-color: #333366;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .complain-form button:hover {
            background-color: #4A4A80;
        }

        /* Footer styles */
        footer {
            background-color: #333366;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: absolute;
            bottom: 0;
            width: 100%;
            transition: background-color 0.3s ease-in-out;
        }

        footer:hover {
            background-color: #666699;
        }

    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../Homepage/Homepage.php">Parking Management System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                <ul class="navbar-nav ms-auto mb-2 mx-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active btn btn-primary" aria-current="page" href="../Login/Login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link profile-btn" href="../Profile/index.php">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="complain-form">
            <h2 class="text-center mb-4">Submit Your Complain</h2>
            <textarea id="complain-text" placeholder="Type your complain here..."></textarea>
            <button class="text-center" onclick="submitComplain()">Submit</button>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Parking Management System</p>
    </footer>

    <script>
        function submitComplain() {
            const complainText = document.getElementById('complain-text').value;
            if (complainText.trim() === '') {
                alert('Please enter your complain before submitting.');
                return;
            }
            // Here you can add code to submit the complain to your server or database
            console.log('Complain submitted:', complainText);
            alert('Your complain has been submitted successfully!');
        }
    </script>

</body>

</html>