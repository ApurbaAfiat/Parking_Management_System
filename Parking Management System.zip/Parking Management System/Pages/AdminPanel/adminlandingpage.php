<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/9ad59e1215.js" crossorigin="anonymous"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,900&display=swap" rel="stylesheet">
    <title>Admin Approval Page</title>
</head>
<body>
    <style>
        body{
            background: url(https://cdn.pixabay.com/photo/2021/09/29/08/47/seamless-pattern-6666875_1280.jpg);
        }
        .Welcome-Text {
            position: absolute;
            color: white;
            top: 40%;
            left: 45%;
            transform: translate(-50%, -50%);
            font-family: 'Poppins', sans-serif;
            font-weight: bold;
            font-style: italic;
            font-size: 50px;
        }

        .Welcome-Text2 {
            position:absolute;
            color: white;
            top:45%;
            left:55%;
            transform: translate(-50%,-50%);
            font-family: 'Poppins', sans-serif;
            font-size: 35px;
            font-weight: bold;
            font-style: italic;
        }

        .Welcome-Text3{
            position:absolute;
            color: white;
            top:51%;
            left:60%;
            transform: translate(-50%,-50%);
            font-family: 'Poppins', sans-serif;
            font-size: 55px;
            font-weight: bold;
            font-style: italic;

        }

        .navbar {
            position: absolute;
            left: 30px; /* Use left property instead of transform to move the element horizontally */
            background: rgb(255, 255, 255);
            border-radius: 45px;
            height: 50px;
            width: 95%;
            backdrop-filter: blur(10px);
            opacity: 0.5; /* Apply a blur effect to the background */
            z-index: -1;
        }

        /* button coding */

        .home {
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Poppins', sans-serif;
            
        }

        .home button {
            position: absolute;
            top: 3%;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1;
            font-weight: bold;
            font-size: 13px;
            border: none;
            outline: none;
            background-color: transparent;
            color: #000000;
            
            cursor: pointer;
            transition: transform 0.3s ease; 
        }

        .home button:hover {
            transform: translateX(-50%) scale(1.1); 
        }


        .Creator {
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Poppins', sans-serif;
            
        }

        .Creator button {
            position: absolute;
            top: 2.8%;
            left: 42%;
            transform: translateX(-50%);
            z-index: 1;
            font-weight: bold;
            font-size: 15px;
            border: none;
            outline: none;
            background-color: transparent;
            color: #000000;
            cursor: pointer;
            transition: transform 0.3s ease; 
        }

        .Creator button:hover {
            transform: translateX(-50%) scale(1.1); 
        }

        .Client-Login{
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Poppins',sans-serif;
        }

        .Client-Login button {
            position:absolute;
            top:2.8%;
            left:58%;
            transform:translateX(-50%);
            border: none;
            outline:none;
            z-index: 1;
            background-color: transparent;
            cursor: pointer;
            color: black;
            font-weight: bold;
            font-size: 15px;
            transition: 0.3s ease;

        }

        .Client-Login button:hover {
            transform: translateX(-50%) scale(1.1); 
        }

        .lolidance{
            display:flex;
            align-items: center;
            justify-content: center;
            position: relative;
            width: 50%;
            max-width: 300px;
            margin:0 auto;

        }

        .lolidance video{
            transform: translate(0px,100px);
            width: 100%;
            height: auto;
            display: block;
            mix-blend-mode: screen;
        }

        .creator-button {
            background-color: skyblue;
            height: 50px;
            width: 150px;
            color: white;
            font-size: 15px;
            border: none;
            outline: none;
            cursor: pointer;
            border-radius: 45px;
            position: fixed;
            top: 65%;
            left: 45%;
            transform: translate(-50%, -50%);
            text-decoration: none; /* Remove default link underline */
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 10px rgba(135, 206, 250, 0.8); /* Add glow effect */
            transition: box-shadow 0.3s ease;
        }

        .creator-button:hover {
            box-shadow: 0 0 20px rgba(135, 206, 250, 1); /* Increase glow effect on hover */
        }
        

        .client-button {

            position: fixed;
            color:white;
            background-color: grey;
            font-size: 15px;
            height: 50px;
            width: 150px;
            border: none;
            outline: none;
            cursor: pointer;
            border-radius: 45px;
            top:65%;
            left:60%;
            transform: translate(-50%,-50%);
            text-decoration: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 10px gainsboro;
            transition: box-shadow 0.3s ease;

        }

        .client-button:hover{
            box-shadow: 0 0 20px gainsboro;
        }












    </style>
</body>

<body>

    <div class="Welcome-Text">
        <p>Admin Panel</p>
    </div>

    <div class = "navbar">
    </div>

    <div class="home">
        <button>HOME</button>
    </div>

    <div class="Creator">
        <button> Creator Login </button>
    </div>

    <div class = "Client-Login">
        <button> Client Login </button>
    </div>
 
    <a href="dataretrieve.php"class = "creator-link">
        <button class="creator-button">
            Creator Approval
        </button>
    </a>

    <a href="clientdataretrieve.php"class = "client-link">
        <button class="client-button">
            Client Approval
        </button>
    </a>

</body>
</html>