<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="../../../css/style.css">
    <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <script defer src="../../../js/bootstrap.bundle.js"></script>
    <style>
        /* Stylish background */
        body {
            background-color: #f4f4f4;
            font-family: 'Arial', sans-serif;
        }

        /* Navbar styles */
        .navbar {
            background: linear-gradient(45deg, #333366, #4A4A80);
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
            transition: color 0.3s ease-in-out;
            font-weight: bold;
        }

        .navbar-brand:hover,
        .nav-link:hover {
            color: #FFCC00 !important;
        }

        /* Styles for colorful rectangles */
        .colorful-rect-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            margin-top: 200px;
        }

        .colorful-rect {
            height: 200px;
            width: 300px;
            margin: 20px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out, transform 0.3s ease-in-out;
            position: relative;
            overflow: hidden;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .colorful-rect:hover {
            opacity: 0.9;
            transform: scale(1.05);
        }

        .fix-slot {
            background-color: #FF5733;
            background-image: url('path/to/image1.jpg'); /* Replace with your image path */
        }

        .pay-bill {
            background-color: #A020F0;
            background-image: url('path/to/image2.jpg'); /* Replace with your image path */
        }

        .complain {
            background-color: #3357FF;
            background-image: url('path/to/image3.jpg'); /* Replace with your image path */
        }

        /* Hover content */
        .hover-content {
            position: absolute;
            left: 0;
            right: 0;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            text-align: center;
            padding: 10px;
            opacity: 0;
            transition: opacity 0.3s ease-in-out;
            border-radius: 0 0 15px 15px;
        }

        .colorful-rect:hover .hover-content {
            opacity: 1;
        }

        /* Motto styles */
        .motto {
            text-align: center;
            margin-top: 10px;
        }

        /* Footer styles */
        footer {
            background-color: #333366;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: absolute;
            bottom: 0;
            width: 100%;
            transition: background-color 0.3s ease-in-out;
        }

        footer:hover {
            background-color: #666699;
        }

        /* Profile button styles */
        .profile-btn {
            background-color: #4A90E2;
            border: none;
            color: white;
            padding: 10px 20px;
            margin-left: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out;
            font-weight: bold;
        }

        .profile-btn:hover {
            background-color: #357ABD;
        }

    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Parking Management System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                <ul class="navbar-nav ms-auto mb-2 mx-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active btn btn-primary" aria-current="page" href="../Login/login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link profile-btn" href="../Profile/index.php">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="colorful-rect-container">
            <div class="colorful-rect fix-slot" onclick="redirectTo('fixSlot')">
                Fix Slot
                <div class="hover-content">Easy and convenient parking solutions tailored for you.</div>
            </div>
            <div class="colorful-rect pay-bill" onclick="redirectTo('payBill')">
                Pay your bill
                <div class="hover-content">Hassle-free payment options</div>
            </div>
            <div class="colorful-rect complain" onclick="redirectTo('complain')">
                Complain
                <div class="hover-content">Your feedback matters! Reach out to us for any concerns.</div>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Parking Management System</p>
    </footer>

    <script>
        function redirectTo(page) {
            switch (page) {
                case 'fixSlot':
                    window.location.href = '../Slot/Slot.php'; // Add your Fix Slot URL here
                    break;
                case 'payBill':
                    window.location.href = '../Payment/Payment.php'; // Add your Pay Bill URL here
                    break;
                case 'complain':
                    window.location.href = '../Complain/Complain.php'; // Add your Complain URL here
                    break;
                default:
                    break;
            }
        }
    </script>

</body>

</html>
