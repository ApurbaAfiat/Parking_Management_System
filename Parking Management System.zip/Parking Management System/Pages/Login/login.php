<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <link href="login.css" rel="stylesheet"/>
</head>
<body>
  <div class="login-page">
    <div class="form">
      <form class="register-form">
        <input type="text" placeholder="name"/>
        <input type="password" placeholder="password"/>
        <input type="text" placeholder="email address"/>
        <button>create</button>
        <p class="message">Already registered? <a href="#">Sign In</a></p>
      </form>
      <form class="login-form" action="../Homepage/Homepage.php"> <!-- Added action attribute with the URL of the homepage -->
        <input type="text" placeholder="username"/>
        <input type="password" placeholder="password"/>
        <button type="submit">login</button> <!-- Added type="submit" to trigger form submission -->
        <p class="message">Not registered? <a href="../Register/Register.php">Create an account</a></p>
        <p class="message"> Want to Login as Admin? <a href="../AdminLogin/login.php">Click Here</a></p>
      </form>
    </div>
  </div>
</body>
</html>